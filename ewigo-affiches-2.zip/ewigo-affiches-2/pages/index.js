import React, { useState, useRef } from "react";

export default function Home() {
  const [primary, setPrimary] = useState("#F7941D");
  const [rawData, setRawData] = useState([]);
  const [posters, setPosters] = useState([]);
  const fileInputRef = useRef(null);

  function handleFile(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const json = JSON.parse(reader.result);
        if (Array.isArray(json)) {
          setRawData(json);
        }
      } catch (err) {
        alert("Erreur lecture fichier: " + err.message);
      }
    };
    reader.readAsText(file);
  }

  function buildPosters() {
    setPosters(rawData);
  }

  return (
    <div style={{ fontFamily: "sans-serif", padding: 20 }}>
      <h1 style={{ color: primary }}>Ewigo Saumur — Générateur d’Affiches</h1>
      <input ref={fileInputRef} type="file" accept=".json" onChange={handleFile} />
      <button onClick={buildPosters}>Générer</button>
      <div style={{ marginTop: 20 }}>
        {posters.map((p, i) => (
          <div key={i} style={{ border: "1px solid #ccc", padding: 10, margin: 10 }}>
            <h2>{p.title || "Sans titre"}</h2>
            <p>{p.year} — {p.mileage} km</p>
            <p>{p.price} €</p>
          </div>
        ))}
      </div>
    </div>
  );
}
