# Ewigo Affiches

Application Next.js pour générer des affiches vitrines pour l'agence **Ewigo Saumur**.

## 🚀 Démarrer en local
```bash
npm install
npm run dev
```
Puis ouvre [http://localhost:3000](http://localhost:3000)

## 🌍 Déploiement sur Vercel
1. Poussez ce projet sur votre dépôt GitHub.
2. Sur [vercel.com](https://vercel.com), importez le dépôt.
3. Cliquez **Deploy** → votre application sera en ligne 🎉
